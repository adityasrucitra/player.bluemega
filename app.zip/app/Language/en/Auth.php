<?php

return [
    'firstName' => 'First Name',
    'lastName' => 'Last Name',
    'phone' => 'Phone Number',
    'citizenNumber' => 'Citizen Number',
];
